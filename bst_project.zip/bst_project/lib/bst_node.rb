class BSTNode
  attr_reader :value, :left, :right

  # Phase 00.
  def initialize(value:, left: nil, right: nil)
    @value = value
    @left = left
    @right = right
  end

  # Phase 01.
  def self.insert(root, value)
    if root.nil?
      return BSTNode.new(value: value)
    else 
      if value <= root.value
        left = self.insert(root.left, value)
        return BSTNode.new(value: root.value, left: left, right: root.right)
      else 
        right = self.insert(root.right, value)
        return BSTNode.new(value: root.value, left: root.left, right: right)
      end  
    end 
  end

  def self.find(root, value)
    return nil unless root
    return root if root.value == value

    if value < root.value
      self.find(root.left, value)
    else 
      self.find(root.right, value)
    end 
  end

  # helper methods for #delete:
  def self.maximum(root)
    return nil if root.nil? 
    return root.value unless root.right
    self.maximum(root.right)
    
  end

  def self.delete(root, value)
    if root.value == value
      if root.left.nil?
        return root.right
      elsif root.right.nil?
        return root.left        
      else
        max = self.maximum(root.left)
        new_left = self.delete(root.left, max)
        return BSTNode.new(value: max, left: new_left, right: root.right)
      end
    end

    if value < root.value
      left = self.delete(root.left, value)
      BSTNode.new(value: value, left: left, right: root.right)
    else
      right = self.delete(root.right, value)
      BSTNode.new(value: value, left: root.left, right: right)
    end
  end

  # Phase 02.
  def self.depth(root)
    return 0 if root.nil?

    left_depth = self.depth(root.left)
    right_depth = self.depth(root.right)

    left_depth > right_depth ? left_depth + 1 : right_depth + 1
  end

  def self.is_balanced?(root)
    return true if root.nil?

    if self.is_balanced?(root.left) && self.is_balanced?(root.right) 
      left_depth = self.depth(root.left)
      right_depth = self.depth(root.right)
      (left_depth - right_depth).abs <= 1 
    else 
      false
    end 
  end

  def self.range(root, arr: [], min: nil, max: nil)
    return arr if root.nil?

    self.range(root.left, arr: arr, min: min, max: max) if min.nil? || root.value >= min

    if (min.nil? || root.value >= min) && (max.nil? || root.value < max)
      arr << root.value 
    end 

    self.range(root.right, arr: arr, min: min, max: max) if max.nil? || root.value <= max

    arr
  end
end
